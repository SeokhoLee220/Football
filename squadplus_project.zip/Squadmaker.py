import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
from similarity_core import final_df
import random
import math
from scipy.optimize import linear_sum_assignment
import numpy as np


st.set_page_config(page_title="Squad Style Analyzer", layout="centered")
st.title("Squad Maker")

if 'Name' not in final_df.columns:
    st.error("final_df에 'Name' 열이 없습니다. similarity_core.py를 확인하세요.")
    st.stop()

player_options = final_df['Name'].dropna().unique().tolist()
selected_names = st.multiselect("Select up to 10 players", options=player_options, max_selections=10)

def get_vertical_zone(x):
    if x < 20: return 0
    elif x < 40: return 1
    elif x < 60: return 2
    elif x < 80: return 3
    else: return 4

def get_horizontal_zone(y):
    if y < 20: return 0
    elif y < 40: return 1
    elif y < 60: return 2
    elif y < 80: return 3
    else: return 4

position_points = {
    "LS": (25, 90), "CS": (50, 90), "RS": (75, 90),
    "LWS": (10, 85), "RWS": (90, 85),
    "LW": (10, 70), "RW": (90, 70),
    "LWM": (10, 60), "RWM": (90, 60),
    "LAM": (30, 70), "CAM": (50, 70), "RAM": (70, 70),
    "LACM": (30, 65), "CACM": (50, 65), "RACM": (70, 65),
    "LM": (10, 45), "LCM": (30, 50), "CCM": (50, 50), "RCM": (70, 50), "RM": (90, 45),
    "LDM": (30, 35), "CDM": (50, 35), "RDM": (70, 35),
    "LDCM": (30, 40), "CDCM": (50, 40), "RDCM": (70, 40),
    "LCB": (30, 10), "CB": (50, 10), "RCB": (70, 10),
    "LB": (10, 25), "RB": (90, 25),
    "LWCB": (30, 10), "RWCB": (70, 10)
}

# --- 준비 ---
df = final_df[final_df['Name'].isin(selected_names)].copy()
position_scores = {
    "Striker": 3, "Winger": 2, "Attacking MF": 1,
    "Central MF": 0, "Holding MF": -1,
    "Full - Back": -1, "Center - Back": -1.5
}

df['Score'] = df['Best Position 1'].map(position_scores).fillna(0)
df['Score2'] = df['Best Position 2'].map(position_scores).fillna(0)
start_coords = {}
end_coords = {}

# --- Position Group Map ---
type_zone_map = {
    "DM": ["LDM", "CDM", "RDM", "LDCM", "CDCM", "RDCM", "LCM", "CCM", "RCM"],
    "AM": ["LAM", "CAM", "RAM", "LACM", "CACM", "RACM"],
    "ST": ["LS", "CS", "RS"],
    "WF": ["LWS", "RWS"],
    "WM": ["LWM", "RWM"],
    "SM": ["LM", "RM"],
    "FB": ["LB", "RB"],
    "DEF": ["LCB", "CB", "RCB", "LWCB", "RWCB"]
}

#Start - Striker 배치
st1 = df[df['Best Position 1'] == 'Striker']

if len(st1) == 1:
    start_coords[st1.iloc[0]['Name']] = position_points['CS']
elif len(st1) == 2:
    coords = [position_points['LS'], position_points['RS']]
    for name, coord in zip(st1['Name'], random.sample(coords, 2)):
        start_coords[name] = coord
        
#Start - Winger 배치
wf1 = df[df['Best Position 1'] == 'Winger']
df['IsWinger'] = False

if len(wf1) >= 3:
    df.loc[df['Name'].isin(wf1['Name']), 'IsWinger'] = True
    # Score 높은 순으로 2명만 윙어 유지
    kept_wingers = wf1.sort_values('Score2', ascending=False).head(2)['Name'].tolist()
    to_convert = wf1[~wf1['Name'].isin(kept_wingers)]['Name'].tolist()
    df.loc[df['Name'].isin(to_convert), 'Best Position 1'] = 'Attacking MF'
    df.loc[df['Name'].isin(kept_wingers), 'IsWinger'] = True
else:
    df.loc[df['Name'].isin(wf1['Name']), 'IsWinger'] = True

winger_candidates = df[(df['Best Position 1'] == 'Winger') & (df['IsWinger'])]
foots = winger_candidates.set_index('Name')['Foot'].to_dict()
names = list(foots.keys())

left_footers = [n for n in names if foots[n] == 1]
right_footers = [n for n in names if foots[n] == 0]
both_footers = [n for n in names if foots[n] == 0.5]

if len(left_footers) >= 2:
    chosen_rw = random.choice(left_footers)
    start_coords[chosen_rw] = position_points['RW']
    left_footers.remove(chosen_rw)
    for name in left_footers:
        start_coords[name] = position_points['LW']
else:
    for name in left_footers:
        start_coords[name] = position_points['RW']

if len(right_footers) >= 2:
    chosen_lw = random.choice(right_footers)
    start_coords[chosen_lw] = position_points['LW']
    right_footers.remove(chosen_lw)
    for name in right_footers:
        start_coords[name] = position_points['RW']
else:
    for name in right_footers:
        start_coords[name] = position_points['LW']

for name in both_footers:
    if position_points['LW'] not in start_coords.values():
        start_coords[name] = position_points['LW']
    else:
        start_coords[name] = position_points['RW']

#Start - Midfielder 배치

mf1 = df[df['Best Position 1'].isin(['Attacking MF', 'Central MF', 'Holding MF'])]

if len(mf1) == 4:
    sorted_mf1 = mf1.sort_values('Score2')
    lower_two = sorted_mf1.iloc[:2]['Name'].tolist()
    higher_two = sorted_mf1.iloc[2:]['Name'].tolist()
    ldm = lower_two[0]
    rdm = lower_two[1]
    lcm = higher_two[0]
    rcm = higher_two[1]

    mid_coord_map = {
        ldm: position_points['LDCM'],
        rdm: position_points['RDCM'],
        lcm: position_points['LACM'],
        rcm: position_points['RACM']
    }
    
    for name, coord in mid_coord_map.items():
        start_coords[name] = coord
        
elif len(mf1) >= 5:
    sorted_mf1 = mf1.sort_values('Score2')
    ldm = sorted_mf1.iloc[0]['Name']
    rdm = sorted_mf1.iloc[1]['Name']
    cam = sorted_mf1.sort_values('Score2', ascending=False).iloc[0]['Name']
    others = [n for n in sorted_mf1['Name'] if n not in [ldm, rdm, cam]][:2]
    mid_coord_map = {
        ldm: position_points['LDM'],
        rdm: position_points['RDM'],
        others[0]: position_points['LM'],
        others[1]: position_points['RM'],
        cam: position_points['CAM']
        }
    
    for name, coord in mid_coord_map.items():
        start_coords[name] = coord
    
else:
    amf = df[df['Best Position 1'] == 'Attacking MF']['Name'].tolist()
    cmf = df[df['Best Position 1'] == 'Central MF']['Name'].tolist()
    hmf = df[df['Best Position 1'] == 'Holding MF'].sort_values("Score", ascending=False)['Name'].tolist()
    
    mid_coord_map = {}
    if len(amf) == 1 and len(cmf) == 1 and len(hmf) == 1:
        mid_coord_map = {amf[0]: position_points['LAM'], cmf[0]: position_points['RCM'], hmf[0]: position_points['CDM']}
    elif len(amf) == 2 and len(hmf) == 1:
        mid_coord_map = {amf[0]: position_points['LAM'], amf[1]: position_points['RAM'], hmf[0]: position_points['CDM']}
    elif len(amf) == 2 and len(cmf) == 1:
        mid_coord_map = {amf[0]: position_points['LAM'], amf[1]: position_points['RAM'], cmf[0]: position_points['CCM']}
    elif len(cmf) == 2 and len(hmf) == 1:
        mid_coord_map = {cmf[0]: position_points['LCM'], cmf[1]: position_points['RCM'], hmf[0]: position_points['CDM']}
    elif len(amf) == 1 and len(hmf) == 2:
        mid_coord_map = {amf[0]: position_points['CAM'], hmf[0]: position_points['LDM'], hmf[1]: position_points['RDM']}
    elif len(amf) == 1 and len(cmf) == 2:
        mid_coord_map = {amf[0]: position_points['CAM'], cmf[0]: position_points['LCM'], cmf[1]: position_points['RCM']}
    elif len(cmf) == 1 and len(hmf) == 2:
        mid_coord_map = {cmf[0]: position_points['CCM'], hmf[0]: position_points['LDM'], hmf[1]: position_points['RDM']}
    elif len(cmf) >= 3:
        sorted_cmf = df[df['Name'].isin(cmf)].sort_values('Score2', ascending=False)
        top_scores = sorted_cmf.iloc[:2]
        rest = sorted_cmf.iloc[2:]

        if len(top_scores) == 2:
            score_diff = top_scores.iloc[0]['Score2'] - top_scores.iloc[1]['Score2']
            if score_diff > 1.5:
                cam = top_scores.iloc[0]['Name']
                others = sorted_cmf[sorted_cmf['Name'] != cam].sort_values('Score2')['Name'].tolist()[:2]
                mid_coord_map = {
                    cam: position_points['CAM'],
                    others[0]: position_points['LDM'],
                    others[1]: position_points['RDM']
                }
            else:
                lcm = top_scores.iloc[0]['Name']
                rcm = top_scores.iloc[1]['Name']
                remaining = [n for n in sorted_cmf['Name'] if n not in [lcm, rcm]][0]
                mid_coord_map = {
                    lcm: position_points['LCM'],
                    rcm: position_points['RCM'],
                    remaining: position_points['CDM']
                }
    
    for i, (_, row) in enumerate(mf1.iterrows()):
        if i < len(mid_coord_map):
            start_coords[row['Name']] = mid_coord_map[row['Name']]
            
#Start -Defender 배치

cb1 = df[df['Best Position 1'] == 'Center - Back']
fb1 = df[df['Best Position 1'] == 'Full - Back']

df1 = pd.concat([
    fb1[fb1['Foot'] == 1].sort_values('Score2', ascending=False),            
    cb1[cb1['Foot'] == 1].sort_values('Score2', ascending=False),            
    cb1[cb1['Foot'] == 0.5].sort_values('Score2', ascending=False),           
    cb1[cb1['Foot'] == 0].sort_values('Score2', ascending=True),             
    fb1[fb1['Foot'] == 0].sort_values('Score2', ascending=True) 
]).drop_duplicates('Name')

if len(df1) in [3, 4, 5]:
    if len(df1) == 3:
        coords = [(30, 10), (50, 10), (70, 10)]
    elif len(df1) == 4:
        coords = [position_points['LB'], (30, 10), (70, 10), position_points['RB']]
    elif len(df1) == 5:
        coords = [(10, 15), (30, 10), (50, 10), (70, 10), (90, 15)]

    for i, (_, row) in enumerate(df1.iterrows()):
        if i < len(coords):
            start_coords[row['Name']] = coords[i]

# --- End Coord Mapping ---
method_coords_raw = {
    "Classic Winger": type_zone_map["WF"],
    "Inside Forward": type_zone_map["ST"],
    "Advanced Forward": type_zone_map["ST"],
    "Completed Forward": type_zone_map["ST"],
    "Shadow Striker": type_zone_map["ST"],
    "Carrilero": type_zone_map["SM"],
    "Wing-Back": type_zone_map["SM"],
    "Wide Center - Back": type_zone_map["DEF"],
    "Inverted Full - Back": type_zone_map["DEF"],
    "Half - Back": type_zone_map["DEF"]
}

for role, positions in method_coords_raw.items():
    end_coords[role] = [position_points[pos] for pos in positions if pos in position_points]

# --- 거리 함수 ---
def euclidean(p1, p2):
    return math.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)

# --- 예시 zone 이동 룰 ---
fixed_strikers = df[df['Best Position 1'].fillna('') == 'Striker']['Name'].tolist()

for name in fixed_strikers:
    if name in start_coords:
        end_coords[name] = start_coords[name]

zone_settings = {
    'ST': {
        'bp2': 'Striker',
        'bp1': ['Striker'],
        'relocation': {
            2: [(30, 90), (70, 90)], 3: [(30, 80), (50,90), (70, 80)]
        }
    },
    'WF': {
        'bp2': 'Winger',
        'bp1': ['Winger'],
        'relocation': {
            2: [(10, 70), (90, 70)]
        }
    },
    'AM': {
        'bp2': 'Attacking MF',
        'bp1': ['Attacking MF', 'Winger', 'Central MF', 'Holding MF'],
        'relocation': {
            1: [(50, 70)], 2: [(30, 70), (70, 70)], 3: [(30, 70), (50, 70), (70, 70)],
            4: [(10, 70), (30, 70), (70, 70), (90,70)],
            5: [(10, 70), (30, 70), (50, 70), (70, 70), (90,70)]
        }
    },
    'WM': {
        'bp2': 'Winger',
        'bp1': ['Winger'],
        'relocation': {
            2: [(30, 60), (70, 60)]
        }
    },
    'SM': {
        'bp2': 'Full - Back',
        'bp1': ['Full - Back'],
        'relocation': {
            1: [(50, 50)], 2: [(30, 50), (70, 50)], 3: [(25, 50), (50, 50), (75, 50)]
        }
    },
    'DM': {
        'bp2': ['Holding MF','Central MF'],
        'bp1': ['Center - Back', 'Full - Back','Central MF', 'Holding MF'],
        'relocation': {
            1: [(50, 45)], 2: [(30, 45), (70, 45)], 3: [(25, 45), (50, 45), (75, 45)],
            4: [(25, 45), (40, 45), (60, 45), (75, 45)],
            5: [(10, 45), (30, 45), (50, 45), (70, 45), (90, 45)]
        }
    },
    'DEF': {
        'bp2': ['Center - Back', 'Full - Back'],
        'bp1': ['Full - Back', 'Holding MF','Center - Back'],
        'relocation': {
            1: [(50, 25)], 2: [(30, 20), (70, 20)], 3: [(25, 15), (50, 15), (75, 15)],
            4: [(20, 25), (35, 15), (65, 15), (80, 25)]
        }
    }
}

for zone, config in zone_settings.items():
  
    bp2_roles = config['bp2']
    bp2_roles = [bp2_roles] if isinstance(bp2_roles, str) else bp2_roles

    df_zone = df[
        df['Best Position 2'].isin(bp2_roles) &
        df['Best Position 1'].isin(config['bp1'])
    ]  
    
    if zone == 'AM':
        df_extra1 = df[
           (df['Best Position 2'] == 'Winger') &
            (df['Best Position 1'].fillna('').isin(['Attacking MF', 'Central MF']))
        ]
        df_zone = pd.concat([df_zone, df_extra1]).drop_duplicates('Name')
        
    if zone == 'DM':
        df_extra2 = df[
            (df['Best Position 2'] == 'Attacking MF') &
            (df['Best Position 1'] == 'Full - Back')
        ]
        df_zone = pd.concat([df_zone, df_extra2]).drop_duplicates('Name')
        
    if zone == 'DM':
        df_extra3 = df[
            (df['Best Position 2'] == 'Full - Back') &
            (df['Best Position 1'] == 'Central MF')
        ]
        df_zone = pd.concat([df_zone, df_extra3]).drop_duplicates('Name')
    
    if zone == 'AM':
        df_extra4 = df[
            (df['Best Position 2'].fillna('').isin(['Full - Back', 'Central MF', 'Center - Back'])) &
            (df['Best Position 1'] == 'Attacking MF')
        ]
        df_zone = pd.concat([df_zone, df_extra4]).drop_duplicates('Name')
        
    if zone == 'DM':
        df_extra5 = df[
            (df['Best Position 2'] == 'Holding MF') &
            (df['Best Position 1'] == 'Attacking MF')
        ]
        df_zone = pd.concat([df_zone, df_extra5]).drop_duplicates('Name')
        
    if zone == 'ST':
        df_extra6 = df[
            (df['Best Position 2'].fillna('').isin(['Attacking MF', 'Winger', 'Holding MF', 'Full - Back', 'Central MF', 'Center - Back'])) &
            (df['Best Position 1'] == 'Striker')
        ]
        df_zone = pd.concat([df_zone, df_extra6]).drop_duplicates('Name')
        
    if zone == 'ST':
        df_extra7 = df[
            (
                (df['Best Position 1'].fillna('').isin(['Winger', 'Attacking MF', 'Central MF'])) &
                (df['Best Position 2'].fillna('') == 'Striker')
            )|(
                (df['Best Position 1'].fillna('') == 'Winger') &
                (df['Best Position 2'].fillna('') == 'Full - Back')
            )
        ]
                        
        df_zone = df_extra7.copy()
        
        left_wingers = []
        right_wingers = []

        for _, row in df_zone.iterrows():
            name = row['Name']
            if name not in start_coords:
                continue
            x, y = start_coords[name]
            if x < 50:
                left_wingers.append(name)
            else:
                right_wingers.append(name)

        for name in left_wingers:
            end_coords[name] = (30, 80)
        for name in right_wingers:
            end_coords[name] = (70, 80)
        continue
            
    if zone == 'WM':
        df_wm_fb = df[
        (df['Best Position 2'] == 'Winger') &
        (df['Best Position 1'] == 'Full - Back')
        ]
        
        left_wingers = []
        right_wingers = []

        for _, row in df_wm_fb.iterrows():
            name = row['Name']
            if name not in start_coords:
                continue  
            x, y = start_coords[name]
                
            if x < 50:
                left_wingers.append(name)
            else:
                right_wingers.append(name)

        for name in left_wingers:
            end_coords[name] = position_points['LWM']
        for name in right_wingers:
            end_coords[name] = position_points['RWM']
    
    if zone == 'ST':        
        df_wf_fb = df[
        (df['Best Position 2'] == 'Full - Back') &
        (df['Best Position 1'] == 'Winger')
        ]
    

        left_wingers = []
        right_wingers = []

        for _, row in df_wf_fb.iterrows():
            name = row['Name']
            if name not in start_coords:
                continue  
            x, y = start_coords[name]

            if x < 50:
                left_wingers.append(name)
            else:
                right_wingers.append(name)

        for name in left_wingers:
            end_coords[name] = position_points['LWS']
        for name in right_wingers:
            end_coords[name] = position_points['RWS']

    n = len(df_zone)
    
    if n == 0 or n not in config['relocation']: 
        continue
    target_coords = config['relocation'][n]
    players = df_zone['Name'].tolist()
    cost_matrix = np.full((n, len(target_coords)), np.inf)

    for i, name in enumerate(players):
        if name not in start_coords:
            continue
        sx, sy = start_coords[name]
        for j, (tx, ty) in enumerate(target_coords):
            if (sx < 50 and tx > 50) or (sx > 50 and tx < 50):
                continue  # 가로선 넘으면 제외
            cost_matrix[i, j] = np.sqrt((sx - tx) ** 2 + (sy - ty) ** 2)

    row_ind, col_ind = linear_sum_assignment(cost_matrix)

    for i, j in zip(row_ind, col_ind):
        if np.isfinite(cost_matrix[i, j]):
            name = players[i]
            coord = target_coords[j]
            end_coords[name] = coord
        
# --- 시각화 ---
st.subheader("Team Style")
st.write(f"Total Score: {df['Score'].sum():.1f} → {'Attackive' if df['Score'].sum() > 0 else 'Defensive' if df['Score'].sum() < 0 else 'Balanced'}")

st.subheader("Player Position Table")
st.dataframe(df[['Name', 'Best Position 1', 'Role', 'Best Position 2']].drop_duplicates('Name'))

fig, ax = plt.subplots(figsize=(6, 9))
fig.patch.set_facecolor('mediumseagreen')
ax.set_facecolor('mediumseagreen')

custom_y_lines = [0, 30, 60, 80, 100]
for y in custom_y_lines:
    ax.plot([0, 100], [y, y], color='white', linewidth=0.5)
    
custom_x_lines = [0, 20, 40, 60, 80, 100]
for x in custom_x_lines:
    ax.plot([x, x], [0, 100], color='white', linewidth=0.5)

for name, (x, y) in start_coords.items():
    circle = Circle((x, y), 2, color='#4CAF50', ec='white', lw=0.8)
    ax.add_patch(circle)
    ax.text(x, y - 3.5, name, ha='center', va='top', fontsize=7, color='white')

player_names = df['Name'].tolist()

for name, val in end_coords.items():
    if name not in player_names:
        continue
    coords_list = val if isinstance(val, list) else [val]
    for (x, y) in coords_list:
        circle = Circle((x, y), 2, color='#4CAF50', ec='yellow', lw=0.8)
        ax.add_patch(circle)

for name in df['Name']:
    if name in start_coords and name in end_coords:
        x0, y0 = start_coords[name]
        x1, y1 = end_coords[name]
        ax.plot([x0, x1], [y0, y1], color='white', linewidth=0.8, linestyle='--')

ax.set_xlim(0, 100)
ax.set_ylim(0, 100)
ax.axis('off')

st.pyplot(fig)
print()
print("✅ Complete")