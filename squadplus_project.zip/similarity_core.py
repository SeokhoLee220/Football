import os
os.environ["OMP_NUM_THREADS"] = "1"

import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.preprocessing import StandardScaler
from sklearn.metrics.pairwise import euclidean_distances
from sklearn.cluster import KMeans

df_raw = pd.read_excel('Player Sample 2.xlsx', usecols='A:Y')
df_raw['BirthYear'] = pd.to_numeric(df_raw['BirthYear'], errors='coerce')
df_raw = df_raw.dropna(subset=['BirthYear'])
df_raw['Age'] = 2025 - df_raw['BirthYear'].astype(int)
df_raw['Foot'] = df_raw['Preferred Foot'].map({'Left': 1, 'Right': 0, 'Both': 0.5})
df_raw['Ages'] = (df_raw['Age'] - df_raw['Age'].min()) / (df_raw['Age'].max() - df_raw['Age'].min())

numeric_cols = df_raw.select_dtypes(include=[np.number]).columns
player_stats = df_raw[numeric_cols].values
player_stats_min = player_stats.min(axis=0)
player_stats_max = player_stats.max(axis=0)
player_stats = (player_stats - player_stats_min) / (player_stats_max - 1e-8)

roles_stats = {
    'Striker': ['Goals', 'Shots on Target %', 'Goals / Shots'],
    'Winger': ['Passes into Penalty Area', 'Touches in Att 3rd', 'Take - On Attempted', 'Progressive Carries', 'Carries into Penalty Area'],
    'Attacking MF': ['Key passes', 'Passes into Penalty Area', 'Touches in Att 3rd', 'Carries into Final Third'],
    'Central MF': ['Passes into Final Third', 'Progressive Passes', 'Touches in Mid 3rd'],
    'Holding MF': ['Touches in Mid 3rd', 'Tackles and Interceptions', 'Recoveries'],
    'Full - Back': ['Touches in Mid 3rd', 'Tackles and Interceptions', 'Carries into Final Third', 'Progressive Carrying Distance'],
    'Center - Back': ['Clearances', 'Touches in Def 3rd', 'Progressive Carrying Distance', 'Aerial Duel Won %']
}
role_names = list(roles_stats.keys())

def parse_roles(pos_str):
    return [p.strip() for p in str(pos_str).split(',') if p.strip() in role_names]

train_Y = []
for pos_str in df_raw['Position'][:105]:
    active_roles = parse_roles(pos_str)
    labels = [1 if role in active_roles else 0 for role in role_names]
    train_Y.append(labels)

train_Y = torch.tensor(train_Y, dtype=torch.float32)
train_X = torch.tensor(player_stats[:105], dtype=torch.float32)
predict_X = torch.tensor(player_stats, dtype=torch.float32)  # 전체 129명

class MultiLabelMLP(nn.Module):
    def __init__(self, input_dim, hidden1=64, hidden2=32, output_dim=7):
        super().__init__()
        self.fc1 = nn.Linear(input_dim, hidden1)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Linear(hidden1, hidden2)
        self.relu2 = nn.ReLU()
        self.fc3 = nn.Linear(hidden2, output_dim)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        x = self.relu1(self.fc1(x))
        x = self.relu2(self.fc2(x))
        x = self.sigmoid(self.fc3(x))
        return x

model = MultiLabelMLP(train_X.shape[1], output_dim=len(role_names))
optimizer = optim.Adam(model.parameters(), lr=0.01)
criterion = nn.BCELoss()

for epoch in range(3000):
    model.train()
    optimizer.zero_grad()
    output = model(train_X)
    loss = criterion(output, train_Y)
    loss.backward()
    optimizer.step()

model.eval()
with torch.no_grad():
    predictions = model(predict_X).numpy()

score_df = pd.DataFrame(predictions, columns=[f'Score_{r}' for r in role_names])
score_df['Name'] = df_raw['Name']

results = []
for i, name in enumerate(df_raw['Name']):  # 129명 전체
    score_dict = {role: predictions[i][j] for j, role in enumerate(role_names)}
    sorted_roles = sorted(score_dict.items(), key=lambda x: x[1], reverse=True)
    result = {'Name': name}
    for k in range(min(2, len(sorted_roles))):
        result[f'Best Position {k+1}'] = sorted_roles[k][0]
        result[f'Score {k+1}'] = sorted_roles[k][1]
    results.append(result)

results_df = pd.DataFrame(results)
final_df = pd.merge(score_df, results_df, on='Name')
final_df = pd.merge(final_df, df_raw[['Name', 'Foot', 'Ages']], on='Name', how='left')

score_cols = [col for col in final_df.columns if col.startswith('Score_')]
X = final_df[score_cols].values
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

kmeans = KMeans(n_clusters=6, random_state=42)
final_df['Cluster'] = kmeans.fit_predict(X_scaled)

cluster_centers = scaler.inverse_transform(kmeans.cluster_centers_)
cluster_profiles = pd.DataFrame(cluster_centers, columns=score_cols)
position_labels = [col.replace('Score_', '') for col in score_cols]

cluster_names = []
for _, row in cluster_profiles.iterrows():
    top_roles = row.values.argsort()[-2:][::-1].tolist()
    r1 = position_labels[top_roles[0]]
    r2 = position_labels[top_roles[1]]
    name = f"{r1}/{r2} Type"
    cluster_names.append(name)

cluster_profiles['Cluster Name'] = cluster_names
name_map = {i: name for i, name in enumerate(cluster_names)}
final_df['Cluster Name'] = final_df['Cluster'].map(name_map)

custom_label_map = {
    "Winger/Full - Back Type": "Classic Winger",
    "Winger/Striker Type": "Inside Forward",
    "Winger/Attacking MF Type": "Inverted Winger",
    "Striker/Winger Type": "Advanced Forward",
    "Striker/Attacking MF Type": "Completed Forward",
    "Attacking MF/Central MF Type": "Advanced Playmaker",
    "Attacking MF/Striker Type": "Shadow Striker",
    "Attacking MF/Winger Type": "Mezzala",
    "Central MF/Winger Type": "Carrilero",
    "Central MF/Attacking MF Type": "Roaming Playmaker",
    "Central MF/Holding MF Type": "Deep-Lying Playmaker",
    "Holding MF/Center - Back Type": "Half - Back",
    "Holding MF/Central MF Type": "Pivote",
    "Full - Back/Winger Type": "Wing-Back",
    "Full - Back/Center - Back Type": "Inverted Full - Back",
    "Full - Back/Holding MF Type": "Inverted Wing - Back",
    "Full - Back/Central MF Type": "Inverted Wing - Back",
    "Full - Back/Attacking MF Type" :"Inverted Wing - Back (A)",
    "Center - Back/Full - Back Type": "Wide Center - Back",
    "Center - Back/Holding MF Type": "Libero",
}

def get_positional_role(pos1, pos2):
    key = f"{pos1}/{pos2} Type"
    return custom_label_map.get(key, key)

final_df['Role'] = final_df.apply(lambda row: get_positional_role(row['Best Position 1'], row['Best Position 2']), axis=1)

def get_similar_players(player_name, top_n=7, top_k_roles=3):
    if player_name not in final_df['Name'].values:
        return f"선수 '{player_name}' 를 찾을 수 없습니다."

    foot_series = final_df['Foot'].map({1: 'Left', 0: 'Right', 0.5: 'Both'}).fillna('Unknown')
    foot_onehot = pd.get_dummies(foot_series, prefix='Foot')
    feature_df = pd.concat([final_df[score_cols], foot_onehot, final_df[['Ages']]], axis=1)

    similarity_cols = feature_df.columns
    X_raw = feature_df.to_numpy(dtype=np.float32)

    X_top = np.zeros_like(X_raw, dtype=np.float32)
    for i, row in enumerate(X_raw):
        role_indices = [j for j, col in enumerate(similarity_cols) if col.startswith('Score_')]
        top_k_idx = np.argsort(row[role_indices])[-top_k_roles:]
        X_top[i, top_k_idx] = row[top_k_idx]
        X_top[i, -4:] = row[-4:]

    X_z = (X_top - X_top.mean(axis=0)) / (X_top.std(axis=0) + 1e-8)
    distance_matrix = euclidean_distances(X_z)

    idx = final_df[final_df['Name'] == player_name].index[0]
    dist_scores = distance_matrix[idx]
    top_indices = dist_scores.argsort()[1:top_n+1]

    result_df = final_df.loc[top_indices, ['Name', 'Role', 'Foot']].assign(
        Distance=np.round(dist_scores[top_indices], 4)
    )
    result_df['Foot'] = result_df['Foot'].map({1: 'Left', 0: 'Right', 0.5: 'Both'}).fillna('Unknown')
    return result_df

if __name__ == "__main__":
    similar_players = get_similar_players("Nuno Mendes", top_n=7, top_k_roles=3)
    print(similar_players)

